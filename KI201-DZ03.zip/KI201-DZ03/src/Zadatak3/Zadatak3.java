package Zadatak3;

import java.util.ArrayList;
import java.util.List;

public class Zadatak3 {

    public static void main(String[] args) {

        List<Automobil> auto = new ArrayList<>();

        Zadatak3 test = new Zadatak3();

        auto.add(test.new Automobil("Mazda", "M", 1990));
        auto.add(test.new Automobil("Honda", "C", 2000));
        auto.add(test.new Automobil("Ford", "S", 1987));
        auto.add(test.new Automobil("BMW", "X3", 2017));
        auto.add(test.new Automobil("Audi", "S", 2003));
        auto.add(test.new Automobil("Honda", "Civic", 2006));
        auto.add(test.new Automobil("Nissan", "S", 2004));
        auto.add(test.new Automobil("Mercedes", "S", 2011));
        auto.add(test.new Automobil("Toyota", "S", 1997));
        auto.add(test.new Automobil("Fiat", "S", 1992));

        auto.sort((Automobil a1, Automobil a2) -> a1.getGodina() - a2.getGodina());

        auto.forEach((p) -> System.out.println(" " + p.toString()));

    }

    private class Automobil {

        private String marka;
        private String model;
        private int godina;

        public Automobil(String marka, String model, int godina) {
            this.marka = marka;
            this.model = model;
            this.godina = godina;
        }

        public String getMarka() {
            return marka;
        }

        public void setMarka(String marka) {
            this.marka = marka;
        }

        public String getModel() {
            return model;
        }

        public void setModel(String model) {
            this.model = model;
        }

        public int getGodina() {
            return godina;
        }

        public void setGodina(int godina) {
            this.godina = godina;
        }

        @Override
        public String toString() {
            return "Automobil[" + "marka=" + marka + ", model=" + model + ", godina=" + godina + ']';
        }

    }

}
