package RadionicaDva;

public class Zadatak1 {

    public static void main(String[] args) {

        int[] niz = new int[]{4, 20, 55, 101, 5, 23, 56, 14, 38, 62};
        System.out.println(max(niz, 9));
    }

    public static int max(int[] niz, int i) {

        if (i == 0) {
            return niz[i];
        }

        int rekurzija = max(niz, i - 1);

        if (rekurzija > niz[i]) {
            return rekurzija;
        } else {
            return niz[i];
        }

    }

}
