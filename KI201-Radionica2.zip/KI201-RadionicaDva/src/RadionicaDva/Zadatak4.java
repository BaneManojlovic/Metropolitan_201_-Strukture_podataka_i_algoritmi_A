package RadionicaDva;

import java.util.*;

public class Zadatak4 {

    public static void main(String[] args) {
        // Stavljanje teksta u String

        String text = "Klasa Collection sadrži statičke metode za liste i kolekcije kao i metode za kreiranje "
                + "nepromenljivih singularnih setova "
                + "listi i mapa kao i za kreiranje nepromenljivih setova listi i mapa ";

        // Kreiranje TreeMap za smeštaj reči, kao ključeva, i broja javljanja, kao vrednost 
        Map<String, Integer> map = new HashMap<>();

        String[] words = text.split(" ");
        
        for (int i = 0; i < words.length; i++) {
            String key = words[i].toLowerCase();

            if (key.length() > 0) {
                if (!map.containsKey(key)) {
                    map.put(key, 1);
                } else {
                    int value = map.get(key);
                    value++;
                    map.put(key, value);
                }
            }
        }

        // Uzimanje svih ulaza u u set
        Set<Map.Entry<String, Integer>> entrySet = map.entrySet();

        // Dobijanje ključa i vrednosti za svaki ulaz
        for (Map.Entry<String, Integer> entry : entrySet) {
            System.out.println(entry.getValue() + "\t" + entry.getKey());
        }
    }
}
