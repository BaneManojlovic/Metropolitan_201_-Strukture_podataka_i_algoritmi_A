package RadionicaDva;

import java.util.Arrays;

public class Zadatak5 {

    public static void main(String[] args) {
        int size = 10;
        int[] data = new int[size];

        for (int i = 0; i < data.length; i++) {
            data[i] = (int) (Math.random() * 20);
        }
        System.out.println(Arrays.toString(data));
        System.out.println(minimum(data, 0, 9));
    }

    static int minimum(int[] array, int z, int k) {
        //ako se niz sastoji iz jednog elementa 
        if (z == k) {
            //minimum je taj element 
            return array[z];
        }
        //naci sredinu niza:
        int s = (z + k) / 2;
        //naci minimum prve polovine: 
        int min1 = minimum(array, z, s);
        //naci minimum druge polovine:
        int min2 = minimum(array, s + 1, k);
        //vraca minimum od polovina:
        return Math.min(min1, min2);
    }
}
