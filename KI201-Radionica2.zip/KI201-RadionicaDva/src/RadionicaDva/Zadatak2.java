package RadionicaDva;

import java.util.ArrayList;
import java.util.Random;

public class Zadatak2 {

    public static void main(String[] args) {

        ArrayList<Integer> list = new ArrayList<>();
        Random rnd = new Random();

        for (int i = 0; i < 10; i++) {
            list.add(rnd.nextInt(100));
        }

        System.out.println(list);
        sort(list);
        System.out.println(list);

    }

    public static <E extends Comparable<E>> void sort(ArrayList<E> list) {

        for (int i = 0; i < list.size() - 1; i++) {
            E trenutniMin = list.get(i);
            int min = i;
            for (int j = i + 1; j < list.size(); j++) {

                if (list.get(j).compareTo(trenutniMin) < 0) {
                    trenutniMin = list.get(j);
                    min = j;
                }
            }

            if (min != i) {
                list.set(min, list.get(i));
                list.set(i, trenutniMin);
            }
        }
    }

}
