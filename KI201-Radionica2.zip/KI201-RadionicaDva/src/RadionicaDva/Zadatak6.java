package RadionicaDva;

import java.util.Collections;
import java.util.HashMap;

public class Zadatak6 {

    public static void main(String[] args) {

        int niz[] = new int[]{5, 20, 17,20, 43, 5, 67, 33, 51, 22, 13, 5};

        HashMap<Integer, Integer> mapaEl = new HashMap<>();
        
        for (int i = 0; i < niz.length; i++) { 

            if (!mapaEl.containsKey(niz[i])) {  // svaki kljuc u mapi kada se doda prvi put
                mapaEl.put(niz[i], 1);         //dobija vrednost 1  
            } else {
                mapaEl.put(niz[i], mapaEl.get(niz[i]) + 1); // brojac
            }                                       // svaki put kada se kljuc ponovo pojavi u mapi 
                                                   //vrednost za taj kljuc se povecava za 1
        }
        int max = Collections.max(mapaEl.values());  //int max sadrzi vrednost kljuca koji se ponovio najvise puta
        HashMap<Integer, Integer> maxMapEl = new HashMap<>();
        mapaEl.forEach((key, value) -> {      //prolazimo kroz mapu 
            if (value >= max) {              //i pravimo novu mapu sa vrednostima koje su vece ili jednake od max
                maxMapEl.put(key, value);
            }
        });

        System.out.println("Broj sa najvise ponavljanja je: "); 
        maxMapEl.forEach((key, value)        //stampanje mape forEah petljom
                -> System.out.println("broj " +key + " se pojavio " + value + " puta"));
    }

}
