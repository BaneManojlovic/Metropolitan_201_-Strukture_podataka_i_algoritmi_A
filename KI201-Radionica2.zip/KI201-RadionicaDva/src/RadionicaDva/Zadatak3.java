package RadionicaDva;

import java.util.ArrayList;
import java.util.Scanner;

public class Zadatak3 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        GenerickiStack<String> stack = new GenerickiStack<String>();

        System.out.println("Unesite string: ");

        String string = "";
        string = scanner.nextLine();

        for (int i = 0; i < string.length(); i++) {

            stack.push(string.substring(i, i + 1)); // "sece" string na slova i redja ih u stack
         }

        String stringnaopako = "";
        while (!stack.isEmpty()) {

            stringnaopako += stack.pop();   // vadi slova iz stack-a i pravi string od slova
        }

        System.out.println("Obrnuti string od \"" + string + "\" je: \"" + stringnaopako + "\"");

    }

}

class GenerickiStack<E> extends ArrayList<E> {  //genericka stack klasa

    public E peek() {
        return get(size() - 1);
    }

    public void push(E o) {
        add(o);
    }

    public E pop() {
        E o = get(size() - 1);
        remove(size() - 1);
        return o;
    }

    @Override
    public boolean isEmpty() {
        return super.isEmpty();
    }

}
