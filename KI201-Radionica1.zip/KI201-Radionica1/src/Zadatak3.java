
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author B&S
 */
public class Zadatak3 {

    public static void main(String[] args) {

        List<Automobil> list = new ArrayList<>();
        list.add(new Automobil("Zastava", "Yugo", 1989));
        list.add(new Automobil("Mercedes", "C", 2000));
        list.add(new Automobil("Mazda", "D", 2008));
       
        // Collections.sort(list, (Automobil e1, Automobil e2)-> e1.getGodiste() - e2.getGodiste());
           Collections.sort(list, (Automobil e1, Automobil e2)-> e1.getMarka().compareTo(e2.getMarka()));
           //string mora da sortira sa compareTo ne može se oduzimati 
           
           
           
        //Collections.sort(list, (e1, e2)-> {return e1.getGodiste() - e2.getGodiste));}
        // može i obrnuti redosled tj. e2 - e1
        
        
        
        System.out.println(list);
       
    }
}

