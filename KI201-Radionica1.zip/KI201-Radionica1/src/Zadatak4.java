
import java.util.HashMap;
import java.util.Map;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author B&S
 */
public class Zadatak4 {

    public static void main(String[] args) {

        Map<String, String> mapa = new HashMap<>();
        mapa.put("Srbija", "Beograd");
        mapa.put("Francuska", "Pariz");
        mapa.put("Grčka", "Atina");

        //System.out.println(mapa.get("Srbija"));

        String vrednost = mapa.get("Srbija");
        if (vrednost != null) {
            System.out.println(vrednost);
        } else {
            System.out.println("Nemamo podatke za tu državu!");

        }
    }
}
 //mapa.put("Srbija", "Niš") menja Beograd u Niš....i onda Sout....