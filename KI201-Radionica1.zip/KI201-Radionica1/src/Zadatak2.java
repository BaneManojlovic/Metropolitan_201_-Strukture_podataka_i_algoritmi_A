
import java.util.Arrays;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author B&S
 */
public class Zadatak2 {

    public static void main(String[] args) {
        Integer[][] niz = {{1, 2}, {3, 4}};
        //String[][] niz = {{"ana", "pera"}, {"jovan", "stefan"}};
        System.out.println(max(niz));
        //Arrays.sort(niz);
        // može isto i za String String[][] niz = duple uglaste zagrade.....
    }

    /*Implementirati sledeći metod koji vraća
    maksimalan element dvodimenzionalnog niza.
     */
    public static <E extends Comparable<E>> E max(E[][] niz) {

        E max = niz[0][0];
        for (E[] row : niz) {
            for (E el : row) {
                if (el.compareTo(max) > 0) {
                    max = el;
                }
            }
        }
        return max;
    }
}
