
import java.util.Arrays;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author B&S
 */
public class Zadatak5 {
    
    // bitno je sortiranje za nlogn!!!!!  pa primenjivati binarnu pretragu....!!!!
    // pa raditi oduzimanje s - n
                                // binarna - logn!!! 
    
    public static void main(String[] args) {
        int[] niz = null;
                    Arrays.sort(niz);
        int element = 0;
                    Arrays.binarySearch(niz, element);
        
    }
}
