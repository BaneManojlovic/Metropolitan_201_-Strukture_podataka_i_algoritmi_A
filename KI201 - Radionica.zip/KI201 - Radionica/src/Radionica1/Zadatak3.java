/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Radionica1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author student
 */
public class Zadatak3 {

    public static void main(String[] args) {

        List<Integer> list = new ArrayList<>();

        list.add(2);
        list.add(5);
        list.add(65);
        list.add(3);

        System.out.println(list);

        Collections.sort(list);

        System.out.println(list);

        List<Automobil> list1 = new ArrayList<>();

        list1.add(new Automobil("Fiat", "Punto", 2001));
        list1.add(new Automobil("Zastava", "Yugo", 1989));
        list1.add(new Automobil("VW", "Polo", 1996));

        Collections.sort(list1);

        System.out.println(list1);
        
        Collections.sort(list1, (e1, e2) -> e1.getGodiste() - e2.getGodiste());
        
        //Collections.sort(list1, (e1, e2) -> { return e1.getGodiste() - e2.getGodiste(); } );
        
        Collections.sort(list1, (e1, e2) ->  -e1.getMarka().compareTo(e2.getMarka()) );

         System.out.println(list1);
        
    }

}
