/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Radionica1;

/**
 *
 * @author student
 */
public class Zadatak2 {

    public static void main(String[] args) {

        String[][] niz = {{"ana", "pera"}, {"jovana", "stefan"}};

        System.out.println(max(niz));

    }

    public static <E extends Comparable<E>> E max(E[][] niz) {

        E max = niz[0][0];

        for (E[] row : niz) {
            for (E el : row) {
                if (el.compareTo(max) > 0) {
                    max = el;
                }
            }
        }
        return max;
    }

}
