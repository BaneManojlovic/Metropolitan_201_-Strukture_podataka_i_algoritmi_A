/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Radionica1;

/**
 *
 * @author student
 */
public class Zadatak1 {

    public static void main(String[] args) {

        System.out.println(zbirCifara(1234));

    }

    public static int zbirCifara(int n) {

        if (n == 0) {
            return 0;
        }
        return zbirCifara(n / 10) + n % 10;

    }

}
