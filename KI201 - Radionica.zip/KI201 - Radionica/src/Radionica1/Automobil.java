package Radionica1;

public class Automobil implements Comparable {

    private String marka;
    private String model;
    private int godiste;

    public Automobil(String marka, String model, int godiste) {
        this.marka = marka;
        this.model = model;
        this.godiste = godiste;
    }

    @Override
    public String toString() {
        return "Automobil{" + "marka=" + marka + ", model=" + model + ", godiste=" + godiste + '}';
    }

    @Override
    public int compareTo(Object o) {

        Automobil other = (Automobil) (o);

        return this.godiste - other.godiste;  //rastuci  poredak

        // return other.godiste - this.godiste; opadajuci
    }

    public String getMarka() {
        return marka;
    }

    public void setMarka(String marka) {
        this.marka = marka;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getGodiste() {
        return godiste;
    }

    public void setGodiste(int godiste) {
        this.godiste = godiste;
    }

    
    
    
}
