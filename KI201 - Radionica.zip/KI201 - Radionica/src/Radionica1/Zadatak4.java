/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Radionica1;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author student
 */
public class Zadatak4 {

    public static void main(String[] args) {

        Map<String, String> mapa = new HashMap<>();

        mapa.put("Srbija", "Beograd");
        mapa.put("Francuska", "Pariz");
        mapa.put("Grcka", "Atina");

        System.out.println(mapa.get("Srbija"));
        //mapa.get("Srbija");

        // System.out.println(mapa.get("Srbija"));
        String vrednost = mapa.get("Bugarska");

        if (vrednost != null) {
            System.out.println(vrednost);
        } else {
            System.out.println("nemamo podatke za tu drzavu");
        }

        mapa.containsKey("Srbija");

        System.out.println(mapa.get("Srbija"));
        mapa.put("Srbija", "Nis");
        System.out.println(mapa.get("Srbija"));

    }

}
