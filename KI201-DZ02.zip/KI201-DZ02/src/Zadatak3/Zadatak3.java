package Zadatak3;

public class Zadatak3 {

    public static void main(String[] args) {

        Integer[] intArray = {2, 4, 3, 5, 1, 4, 2};

        String[] stringArray = {"Pera", "Mile", "Djole", "Mile", "Pera"};

        Character[] charArray = {'a', 'b', 'b', 'a'};

        System.out.println(symm(intArray));

        System.out.println(symm(stringArray));

        System.out.println(symm(charArray));

    }

    public static <E extends Comparable<E>> boolean symm( E[] list ) {

        int i1 = 0;
        int i2 = list.length - 1;

        while (i2 > i1) {
            if (list[i1].compareTo(list[i2]) != 0) {
                return false;
            }
            i1++;
            i2--;
        }
        return true;

    }

}
