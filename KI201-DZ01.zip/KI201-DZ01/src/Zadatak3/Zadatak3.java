package Zadatak3;

import java.util.Scanner;

public class Zadatak3 {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.print("Unesite broj : ");
        int broj = input.nextInt();
        
        System.out.println("Da li je broj cifara " + broj + " paran?");
        System.out.println("Odgovor je:" + daLiJeBrojCifaraParan(broj));

    }

    public static boolean daLiJeBrojCifaraParan(int n) {

        if (n >= 10) {
            return !daLiJeBrojCifaraParan(n / 10);
        } else {
            return false;
        }

    }

}
